# Git Hooks

You should save your git hooks in this directory and make sure they have their **execute** flag set.
