
# File Uploads

Any files uploaded by the user will be stored in this directory.
